/*
 * @Descripttion: 
 * @Author: Hx
 * @Date: 2021-12-21 20:59:30
 * @LastEditors: Hx
 * @LastEditTime: 2021-12-21 20:59:30
 */
// file
char input_file[100];
char output_file[100];
char *buffer;
int fsize;

// record
int new_key;
int new_pos;
int new_len;
char new_st[12];

// data
int validRecords;

// test
int keys[10000000];
int key_num;